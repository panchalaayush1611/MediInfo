# MediInfo-Project
A Medical Website for  College Projects
