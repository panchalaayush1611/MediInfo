const li = document.getElementById("change_theme");
const theme = document.getElementById('icon1').addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});